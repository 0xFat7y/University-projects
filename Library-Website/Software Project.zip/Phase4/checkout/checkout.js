// دالة إتمام الطلب (بتتنفذ لما يضغط Confirm في صفحة الـ Checkout)
function confirmOrder() {
    // 1. جلب بيانات المستخدم
    let currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    // أمان: لو مفيش يوزر، رجعه للوجين
    if (!currentUser) {
        window.location.href = "../login/login.html";
        return;
    }

    let cart = currentUser.cart || [];

    // أمان: لو السلة فاضية (مفروض ميوصلش هنا بس زيادة تأكيد)
    if (cart.length === 0) {
        alert("Your cart is empty!");
        window.location.href = "../shoppingcart/shoppingcart.html";
        return;
    }

    // 2. حساب السعر الكلي
    let totalAmount = 0;
    cart.forEach(item => totalAmount += (parseFloat(item.price) * (item.qty || 1)));

    // 3. إنشاء الأوردر
    let newOrder = {
        orderId: Date.now(),
        date: new Date().toLocaleDateString(),
        time: new Date().toLocaleTimeString(),
        status: "Pending", // الحالة لسه معلقة
        total: totalAmount.toFixed(2),
        items: cart, // الكتب اللي اشتراها
        // هنا ممكن تضيف بيانات العنوان لو عندك inputs في صفحة الـ checkout
        customerName: currentUser.username,
        customerPhone: currentUser.phone
    };

    // 4. الحفظ عند الأدمن (All Orders)
    let allOrders = JSON.parse(localStorage.getItem('allOrders')) || [];
    allOrders.push(newOrder);
    localStorage.setItem('allOrders', JSON.stringify(allOrders));

    // 5. الحفظ عند المستخدم (My Orders)
    if (!currentUser.orders) currentUser.orders = [];
    currentUser.orders.push(newOrder);

    // 6. تفريغ السلة (خلاص اشترى)
    currentUser.cart = [];
    
    // 7. تحديث الداتا في الـ LocalStorage
    localStorage.setItem("currentUser", JSON.stringify(currentUser));
    updateUserInMainDB(currentUser); // تحديث قاعدة البيانات الرئيسية

    // 8. التوجيه لصفحة "تم الشراء بنجاح"
    window.location.href = "../successfulpurchase/successfulpurchase.html";
}

// دالة مساعدة لتحديث اليوزر في قاعدة البيانات الكبيرة
function updateUserInMainDB(updatedUser) {
    let users = JSON.parse(localStorage.getItem('users')) || [];
    let index = users.findIndex(u => u.username === updatedUser.username);
    if (index !== -1) {
        users[index] = updatedUser;
        localStorage.setItem('users', JSON.stringify(users));
    }
}