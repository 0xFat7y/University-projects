// 1. تعريف العناصر
const cartList = document.getElementById("cartList");
const subtotalValue = document.getElementById("subtotalValue");

// 2. التحقق من المستخدم عند التحميل
document.addEventListener('DOMContentLoaded', () => {
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    
    // لو مفيش يوزر، نرجعه للوجين
    if (!currentUser) {
        window.location.href = "../login/login.html";
    } else {
        renderCart();
        updateTotal();
    }
});

// 3. دالة رسم السلة (بناءً على كودك الأصلي)
function renderCart() {
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    let cart = currentUser.cart || [];

    cartList.innerHTML = "";

    if (cart.length === 0) {
        cartList.innerHTML = "<p style='text-align:center; padding:20px;'>Your cart is empty.</p>";
        return;
    }

    cart.forEach(item => {
        // تأكد إن أسماء المتغيرات هنا (img, title, price) مطابقة للي انت بتخزنه في زرار Add to Cart
        const html = `
        <div class="cart-item">
            <img class="book-img" src="${item.image || item.img}"> 
            
            <div class="item-info">
                <h3 class="book-title">${item.name || item.title}</h3>
                <p class="book-stock">In Stock</p>
            </div>

            <div class="item-actions">
                <p class="book-price" data-price="${item.price}">$${item.price}</p>

                <div class="qty-controls">
                    <button class="qty-btn minus">-</button>
                    <span class="qty-num">${item.qty || 1}</span> 
                    <button class="qty-btn plus">+</button>
                </div>

                <button class="delete-btn" data-title="${item.name || item.title}">×</button>
            </div>
        </div>
        `;
        cartList.insertAdjacentHTML("beforeend", html);
    });
}

// 4. الاستماع للأحداث (الضغط على الزراير)
cartList.addEventListener("click", e => {
    // التقاط اسم الكتاب من أقرب عنصر أب (عشان الدقة)
    const wrapper = e.target.closest(".cart-item");
    
    if (e.target.classList.contains("plus")) {
        let title = wrapper.querySelector(".book-title").textContent;
        changeQty(title, 1);
    }
    
    if (e.target.classList.contains("minus")) {
        let title = wrapper.querySelector(".book-title").textContent;
        changeQty(title, -1);
    }
    
    if (e.target.classList.contains("delete-btn")) {
        let title = e.target.dataset.title;
        deleteItem(title);
    }
});

// 5. دالة تغيير الكمية
function changeQty(title, step) {
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    // بندور في سلة المستخدم الحالي
    let book = currentUser.cart.find(i => (i.name === title || i.title === title));

    if (book) {
        // لو الكمية مش موجودة افترض انها 1
        if (!book.qty) book.qty = 1;
        
        book.qty = Math.max(1, book.qty + step);

        // حفظ التعديلات
        localStorage.setItem("currentUser", JSON.stringify(currentUser));
        updateMainDatabase(currentUser); // تحديث قاعدة البيانات الرئيسية

        renderCart(); // إعادة الرسم لتحديث الأرقام
        updateTotal();
    }
}

// 6. دالة الحذف
function deleteItem(title) {
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    
    // فلتر السلة وشيل الكتاب ده
    currentUser.cart = currentUser.cart.filter(i => (i.name !== title && i.title !== title));

    // حفظ التعديلات
    localStorage.setItem("currentUser", JSON.stringify(currentUser));
    updateMainDatabase(currentUser);

    renderCart();
    updateTotal();
}

// 7. حساب الإجمالي
function updateTotal() {
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    let cart = currentUser ? (currentUser.cart || []) : [];
    let total = 0;

    cart.forEach(item => {
        let quantity = item.qty || 1;
        let price = parseFloat(item.price); // تحويل النص لرقم
        total += price * quantity;
    });

    // تحديث الرقم في الشاشة
    if(subtotalValue) {
        subtotalValue.textContent = "$" + total.toFixed(2);
        // كمان بنحدث الـ id اللي اسمه totalPrice عشان زرار الـ checkout يشوفه
        const totalSpan = document.getElementById('totalPrice');
        if(totalSpan) totalSpan.innerText = total.toFixed(2);
    }
}

// 8. دالة الشراء (Checkout) - دي اللي بتنهي العملية
function checkout() {
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));
    let cart = currentUser.cart || [];

    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    let totalAmount = 0;
    cart.forEach(item => totalAmount += (parseFloat(item.price) * (item.qty || 1)));

    // تجهيز الأوردر
    let newOrder = {
        orderId: Date.now(),
        date: new Date().toLocaleDateString(),
        time: new Date().toLocaleTimeString(),
        status: "Pending",
        total: totalAmount.toFixed(2),
        items: cart,
        customerName: currentUser.username,
        customerPhone: currentUser.phone
    };

    // حفظ للأدمن
    let allOrders = JSON.parse(localStorage.getItem('allOrders')) || [];
    allOrders.push(newOrder);
    localStorage.setItem('allOrders', JSON.stringify(allOrders));

    // حفظ لليوزر
    if (!currentUser.orders) currentUser.orders = [];
    currentUser.orders.push(newOrder);

    // تفريغ السلة
    currentUser.cart = [];
    
    // حفظ نهائي
    localStorage.setItem("currentUser", JSON.stringify(currentUser));
    updateMainDatabase(currentUser);

    window.location.href = "../successfulpurchase/successfulpurchase.html";
}

// 9. دالة مساعدة لتحديث الداتا الكبيرة (Users Array)
function updateMainDatabase(updatedUser) {
    let users = JSON.parse(localStorage.getItem('users')) || [];
    let index = users.findIndex(u => u.username === updatedUser.username);
    if (index !== -1) {
        users[index] = updatedUser;
        localStorage.setItem('users', JSON.stringify(users));
    }
}




