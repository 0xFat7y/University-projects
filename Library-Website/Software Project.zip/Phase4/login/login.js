function loginBtnClicked() {
    // هنا بنجيب القيم اللي اليوزر كتبها في الـ HTML
    let inputVal = document.getElementById('identifier').value;
    let passVal = document.getElementById('password').value;

    // بننادي على دالة اللوجين الأساسية اللي شرحناها قبل كدا
    handleLogin(inputVal, passVal);
}

// ... باقي كود handleLogin اللي كتبناه فوق ...

// بيانات موظفين افتراضية لو مفيش داتا (عشان تقدر تدخل وتجرب)
const defaultEmployees = [
    { username: "admin", password: "123", role: "employee" }
];

// دالة تسجيل الدخول
function handleLogin(inputUser, inputPass) {
    // 1. جلب البيانات من الـ LocalStorage
    let users = JSON.parse(localStorage.getItem('users')) || [];
    let employees = JSON.parse(localStorage.getItem('employees')) || defaultEmployees;

    // 2. البحث في الموظفين أولاً (حسب طلبك)
    let foundEmp = employees.find(e => 
        (e.username === inputUser || e.email === inputUser || e.phone === inputUser) && 
        e.password === inputPass
    );

    if (foundEmp) {
        // حفظ الموظف الحالي في الجلسة
        localStorage.setItem('currentUser', JSON.stringify(foundEmp));
        // توجيه لصفحة الموظف (حسب اسم الملف في الصور عندك)
        window.location.href = "../EmployeeMainMenu/EmployeeMainMenu.html";
        return;
    }

    // 3. البحث في المستخدمين
    let foundUser = users.find(u => 
        (u.username === inputUser || u.email === inputUser || u.phone === inputUser) && 
        u.password === inputPass
    );

    if (foundUser) {
        // حفظ المستخدم الحالي
        localStorage.setItem('currentUser', JSON.stringify(foundUser));
        // توجيه لصفحة المستخدم الرئيسية
        window.location.href = "../MainMenu/MainMenu.html";
        return;
    }

    // 4. لو مش موجود
    alert("Incorrect data, you will be directed to create an account");
    window.location.href = "../signup/signup.html";
}