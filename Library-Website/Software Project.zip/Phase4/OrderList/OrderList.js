document.addEventListener('DOMContentLoaded', () => {
    loadUserOrders();
});

function loadUserOrders() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    if (!currentUser) {
        window.location.href = "../login/login.html";
        return;
    }

    const tableBody = document.getElementById('tableBody');
    const orders = currentUser.orders || [];

    if (orders.length === 0) return;

    tableBody.innerHTML = '';

    orders.reverse().forEach(order => {
        
        const addressInfo = currentUser.address || currentUser.phone || "N/A";

        const row = `
            <tr>
                <td style="font-weight: bold; color: #001356;">#${order.orderId.toString().slice(-6)}</td>
                
                <td>
                    <span style="
                        background-color: #e3f2fd; 
                        color: #0d47a1; 
                        padding: 5px 12px; 
                        border-radius: 20px; 
                        font-size: 0.85em; 
                        font-weight: 600;">
                        ${order.status}
                    </span>
                </td>
                
                <td style="font-weight: bold;">$${order.total}</td>
                
                <td style="color: #666;">${order.date}</td>
                
                <td style="color: #666;">${addressInfo}</td>
                
                <td>
                    <button onclick="showOrderDetails(${order.orderId})" style="
                        background: none; 
                        border: 1px solid #ddd; 
                        padding: 5px 10px; 
                        border-radius: 5px; 
                        cursor: pointer; 
                        color: #555;
                        transition: 0.3s;">
                        View Books
                    </button>
                </td>
            </tr>
        `;

        tableBody.insertAdjacentHTML('beforeend', row);
    });
}

function showOrderDetails(orderId) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const order = currentUser.orders.find(item => item.orderId == orderId);

    if (order) {
        let booksList = order.items.map(book => {
            return `- ${book.title || book.name} (Qty: ${book.qty || 1})`;
        }).join('\n');

        // التعديل هنا كمان في الرسالة
        alert(`Order #${orderId.toString().slice(-6)} Details:\n\n${booksList}\n\nTotal: $${order.total}`);
    } else {
        alert("Error: Order details not found!");
    }
}