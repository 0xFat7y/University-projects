

function registerUser() {
    // 1. جلب القيم من الـ HTML
    let userVal = document.getElementById('username').value;
    let emailVal = document.getElementById('email').value;
    let phoneVal = document.getElementById('phone').value;
    let passVal = document.getElementById('password').value;

    // 2. التحقق إن الخانات مش فاضية (Validation)
    if (userVal === "" || emailVal === "" || passVal === "" || phoneVal === "") {
        alert("Please fill in all the data!");
        return;
    }

    // 3. جلب قاعدة البيانات الحالية (المستخدمين القدامى)
    // لو مفيش حد خالص، بنعمل مصفوفة فاضية []
    let users = JSON.parse(localStorage.getItem('users')) || [];

    // 4. التأكد إن المستخدم مش موجود قبل كدا (عن طريق الإيميل أو الاسم)
    let userExists = users.some(u => u.email === emailVal || u.username === userVal);

    if (userExists) {
        
            alert("This user or email is already exist, try logging in .");
        return;
    }

    // 5. تجهيز بيانات المستخدم الجديد
    let newUser = {
        id: Date.now(), // رقم مميز لكل يوزر
        username: userVal,
        email: emailVal,
        phone: phoneVal,
        password: passVal,
        role: 'user', // مهم جداً عشان نميزه عن الموظف
        cart: [],     // سلة فاضية بيبدأ بيها
        orders: []    // تاريخ طلبات فاضي
    };

    // 6. إضافة المستخدم الجديد للقائمة
    users.push(newUser);

    // 7. حفظ القائمة المحدثة في الـ LocalStorage
    localStorage.setItem('users', JSON.stringify(users));

    // 8. التوجيه لصفحة الـ Login (حسب طلبك)
    
alert("Account created successfully! Please log in.");
    window.location.href = "../login/login.html";
}