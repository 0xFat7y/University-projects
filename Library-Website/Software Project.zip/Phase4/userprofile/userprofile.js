document.addEventListener('DOMContentLoaded', () => {
    // 1. جلب بيانات المستخدم المسجل حالياً
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    // 2. لو مفيش حد مسجل دخول، رجعه لصفحة اللوجين (أمان)
    if (!currentUser) {
        window.location.href = "../login/login.html";
        return;
    }

    // 3. تحديث البيانات في الصفحة
    // عرض الاسم
    const nameElement = document.getElementById('displayName');
    if (nameElement) {
        // بنعرض الـ username، ولو مش موجود نعرض "User"
      nameElement.textContent = currentUser.username || "User" 
    }

    // عرض رقم التليفون
    const phoneElement = document.getElementById('displayPhone');
    if (phoneElement) {
        phoneElement.textContent = "Phone: " + (currentUser.phone || "N/A");
    }

    // عرض الإيميل
    const emailElement = document.getElementById('displayEmail');
    if (emailElement) {
        emailElement.textContent = "Email: " + (currentUser.email || "N/A");
    }
});

// دالة تسجيل الخروج
function logout() {
    // بنشيل المستخدم الحالي من الذاكرة
    localStorage.removeItem('currentUser');
    // بنرجعه لصفحة تسجيل الدخول
    window.location.href = "../login/login.html";
}