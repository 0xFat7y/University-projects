document.querySelectorAll(".add-to-cart").forEach(btn => {
  btn.addEventListener("click", () => {

    // 1. التأكد أولاً إن فيه مستخدم مسجل دخول
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));

    if (!currentUser) {
      alert("Please login first to add items to cart.");
      window.location.href = "../login/login.html"; // توجيه لصفحة الدخول
      return;
    }

    // 2. تجهيز بيانات الكتاب
    const book = {
      title: btn.dataset.title,
      price: parseFloat(btn.dataset.price),
      img: btn.dataset.img,
      qty: 1
    };

    // 3. التعامل مع سلة المستخدم الحالي مش السلة العامة
    // لو معندوش سلة، بنعمله واحدة فاضية
    if (!currentUser.cart) {
        currentUser.cart = [];
    }

    // 4. التأكد لو الكتاب موجود قبل كدا
    const exist = currentUser.cart.find(item => item.title === book.title);

    if (exist) {
      exist.qty += 1;
    } else {
      currentUser.cart.push(book);
    }

    // 5. حفظ البيانات في مكانين (مهم جداً)
    
    // أ: حفظ في المستخدم الحالي (Session)
    localStorage.setItem("currentUser", JSON.stringify(currentUser));

    // ب: حفظ في قاعدة البيانات الرئيسية (عشان لو عمل Logout ورجع)
    updateUserInMainDB(currentUser);

    alert("Added to cart successfully!");
  });
});

// دالة مساعدة لتحديث قاعدة البيانات الرئيسية
function updateUserInMainDB(updatedUser) {
    let users = JSON.parse(localStorage.getItem('users')) || [];
    // بندور على اليوزر ده ونحدث بياناته
    let index = users.findIndex(u => u.username === updatedUser.username);
    
    if (index !== -1) {
        users[index] = updatedUser;
        localStorage.setItem('users', JSON.stringify(users));
    }
}