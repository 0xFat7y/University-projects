document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
});

function loadUsers() {
    // 1. جلب الداتا
    const users = JSON.parse(localStorage.getItem('users')) || [];

    // 2. تحديث العدد الكلي فوق
    const countSpan = document.getElementById('usersCount');
    if (countSpan) {
        countSpan.textContent = users.length;
    }

    // 3. مسك الحاوية وتفريغها
    const container = document.getElementById('usersListContainer');
    container.innerHTML = '';

    // 4. رسم كل يوزر بنفس الـ HTML Structure بتاعك
    users.forEach(user => {
        // بنحول الـ ID لتاريخ
        let dateAdded = new Date(user.id).toLocaleDateString();
        
        // بما إننا مش بنسجل "Last Active"، هنعرض رقم التليفون أو الـ Role مكانه
        let secondColumnData = user.phone || "User"; 

        // لاحظ: استخدمت نفس الـ Classes بالظبط اللي في الكود بتاعك
        const userRowHTML = `
            <div class="user-row">
                <div class="user-avatar">
                    <img src="../images/profile-placeholder.png" alt="${user.username}">
                </div>
                <div class="user-info">
                    <div class="user-name">${user.username}</div>
                    <div class="user-email">${user.email}</div>
                </div>
                <div class="user-dates">
                    <span class="date-text">${secondColumnData}</span>
                    <span class="date-text">${dateAdded}</span>
                </div>
            </div>
        `;

        // إضافة الصف للصفحة
        container.innerHTML += userRowHTML;
    });
}