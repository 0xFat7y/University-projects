document.addEventListener('DOMContentLoaded', () => {
    loadAllOrders();
});

function loadAllOrders() {
    const allOrders = JSON.parse(localStorage.getItem('allOrders')) || [];
    const tableBody = document.getElementById('tableBody');

    tableBody.innerHTML = '';

    if (allOrders.length === 0) {
        tableBody.innerHTML = '<p style="text-align:center; padding:20px;">No orders found.</p>';
        return;
    }

    // عرض الطلبات (الأحدث فالأقدم)
    allOrders.reverse().forEach(order => {
        
        // إنشاء الصف (Div)
        const row = document.createElement('div');
        row.classList.add('table-row');

        // تحديد اللون المبدئي للقائمة
        let statusClass = 'pending';
        if (order.status === 'Confirmed') statusClass = 'confirmed';
        if (order.status === 'Rejected') statusClass = 'rejected';

        // ملء البيانات
        row.innerHTML = `
            <div>#${order.orderId.toString().slice(-6)}</div>
            <div style="font-weight:bold; color:#001356;">$${order.total}</div>
            <div>${order.customerName}</div>
            <div>${order.items.length}</div> <div>${order.date}</div>
            <div>
                <select class="${statusClass}" onchange="updateStatus(${order.orderId}, this)">
                    <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
                    <option value="Confirmed" ${order.status === 'Confirmed' ? 'selected' : ''}>Confirm</option>
                    <option value="Rejected" ${order.status === 'Rejected' ? 'selected' : ''}>Reject</option>
                </select>
            </div>
        `;

        tableBody.appendChild(row);
    });
}

// --- دالة تحديث الحالة عند تغيير الاختيار ---
function updateStatus(orderId, selectElement) {
    const newStatus = selectElement.value;

    // 1. تغيير لون الـ Select فوراً
    selectElement.className = ''; // مسح الكلاسات القديمة
    if(newStatus === 'Pending') selectElement.classList.add('pending');
    if(newStatus === 'Confirmed') selectElement.classList.add('confirmed');
    if(newStatus === 'Rejected') selectElement.classList.add('rejected');

    // 2. تحديث المخزن العام (All Orders)
    let allOrders = JSON.parse(localStorage.getItem('allOrders')) || [];
    let orderIndex = allOrders.findIndex(o => o.orderId == orderId);

    if (orderIndex !== -1) {
        allOrders[orderIndex].status = newStatus;
        localStorage.setItem('allOrders', JSON.stringify(allOrders));

        // 3. تحديث بيانات العميل (عشان يشوف الحالة عنده)
        let customerName = allOrders[orderIndex].customerName;
        updateUserSideOrder(customerName, orderId, newStatus);
        
        // رسالة تأكيد صغيرة (اختياري)
        // console.log("Status updated to " + newStatus);
    }
}

// دالة مساعدة لتحديث الأوردر جوه ملف اليوزر
function updateUserSideOrder(username, orderId, newStatus) {
    let users = JSON.parse(localStorage.getItem('users')) || [];
    let userIndex = users.findIndex(u => u.username === username);

    if (userIndex !== -1) {
        let userOrders = users[userIndex].orders || [];
        let specificOrder = userOrders.find(o => o.orderId == orderId);

        if (specificOrder) {
            specificOrder.status = newStatus;
            
            // حفظ التغييرات
            localStorage.setItem('users', JSON.stringify(users));

            // تحديث السيشن لو اليوزر فاتح دلوقتي
            let currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (currentUser && currentUser.username === username) {
                currentUser.orders = userOrders;
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
            }
        }
    }
}